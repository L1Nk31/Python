from array import

a = array(1,1,3,3,5,5,7,7,9,9,11,11,13,15,16)
b = array()


