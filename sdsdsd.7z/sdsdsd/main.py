#1
ab = str('хочу много денег в год и хочу пятерки')
b = ab[0:20]
if b.find('хочу') and b.find('в') and b.find('год'):
    print ('хочу')
    print ('в')
    print ('год')
else:
    print ('нет')
