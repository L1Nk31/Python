# import math
# #3
# a = input()
# b = input()
# c = a + b
# for f in c:
#     print (f)
# else:
#     print (c)
#
# #5
# a = int(input())
# b = math.factorial(a)
# print (b)
import random

# #8
# a = random.randint(0,100)
# for a in range (0,10):
#     b = int(input())
#     if a == b:
#       print ("верно")
#     elif a < b:
#       print ("меньше")
#     elif a > b:
#       print ("больше")
# print ("неверно")
#1
a = int(input())
b = int(input())
if c == 1:
    d = a * b
    print (c)







